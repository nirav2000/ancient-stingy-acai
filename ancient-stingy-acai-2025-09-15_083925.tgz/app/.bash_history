npm run setup
npm run publish
npm run publish
npm run publish
npm run setup
npm run publish
npm run publish
fastly whoami
npm run setup
fastly whoami
fastly update
fastly whoami
npm run publish
npm run publish
npm run publish
npm run setup
npm run setup
npm run setup
npm run setup
npm run publish
npm run publish
npm run publish
npm run deploy
npm publish
npm adduser
fastly publish
fastly whoami
